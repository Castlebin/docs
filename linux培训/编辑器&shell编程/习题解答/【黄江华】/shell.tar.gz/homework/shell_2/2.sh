#Script: 		just for shell homework 2(create dir and file)
#Script name:	2.sh
#example:		./2.sh
#author:		huangjianghua

#! /bin/sh
PWD=$(cd "$(dirname "$0")"; pwd)

#check the number of the input parameters
if [ $# = 0 ]
then
	for (( c=1; c<=10; c++ )) 
	do
		if [ -d $PWD/dir$c ]
		then
			#if exist, delete
			rm -fr  $PWD/dir$c
	
		fi
		#create dir
		mkdir $PWD/dir$c		
		
		#create file and set chmod
		for (( d=1; d<=10; d++ )) 
		do
			touch $PWD/dir$c/file$d
			chmod 755 $PWD/dir$c/file$d
		done
	done
		
	echo "Press 1-10 to select rename..."
	#wait for input
	read num
	echo $num
		
	#check input number is legal
	expr $num + 0 1>/dev/null 2>&1
	if [ $? -ne 0 ]
	then
		echo "not legal!"
		exit 0
	fi

	if [[ $num -lt 1 || $num -gt 10 ]]
	then
		echo "not legal!"
		exit 0
	fi

	#rename 
	echo "rename..."
	filelist=`ls $PWD/dir$num/`
	for file in $filelist
	do 
		mv $PWD/dir$num/$file $PWD/dir$num/$file.bak
 		echo "$file rename to $file.bak"
	done
	
	#save file name to out.txt
	ls $PWD/dir$num/ > out.txt

	#filter:remove dir
	dirlist=`find -type d -name '*' | grep $num`
	for dir in $dirlist
	do 
 		echo "remove dir: $dir"
		rm -fr $PWD/$dir
	done

	#filter:remove file
	filelist=`find -type f -name '*' | grep $num` 
	for file in $filelist
	do 
 		echo "remove file: $file"
		rm -f $PWD/$file
	done 
	
else
	echo "Something wrong with the input parameters!"
	echo "how to call: ./2.sh"
	echo "example: ./2.sh"
fi

