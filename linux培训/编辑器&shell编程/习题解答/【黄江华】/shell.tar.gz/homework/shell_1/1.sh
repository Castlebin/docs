#Script: 		just for shell homework 1(move all .c into the destination dir)
#Script name:	1.sh
#example:		./1.sh /tmp/dir2
#author:		huangjianghua

#! /bin/sh

#check the number of the input parameters
if [ $# = 1 ]
then
	#check the destination dir if exists
	if [ -d $1 ]  
	then
	mv *.c $1/
	ls -lSr $1/
	else 
	echo "The dir is not existed!"; 
	fi
else
	echo "Something wrong with the input parameters!";
	echo "how to call: ./1.sh dir"
	echo "example: ./1.sh /tmp/dir2";
fi

