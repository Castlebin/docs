#Script: 		just for shell homework 3
#Script name:	3.sh
#example:		./3.sh 3 4 6 5
#author:		huangjianghua

#! /bin/sh

#check the number of the input parameters
if [ $# -ge 3 ]
then
	#just echo input
	echo -en "The input numbers : "
	for num in $@
	do
		echo -en "$num "
	done 
	echo ""	

	#check input if legal
	for num in $@
	do
		if [ $num = "0" ]
		then
			continue; 
		fi

		expr $num + 0 1>/dev/null 2>&1
		if [ $? -ne 0 ]
		then
			echo "The iput is not legal!"
			exit 0
		fi
	done 
	
	#calculate
	min=$1
	max=$1
	ave=0
	for num in $@
	do
		ave=`echo "$ave + $num"|bc`
		if [ $min -gt $num ]
		then
			min=$num
		fi
		
		if [ $max -lt $num ]
		then
			max=$num
		fi
		
	done 
	ave=`echo "scale=2; $ave / $#"|bc`	
		
	#show result
	echo "max number is $max"
	echo "min number is $min"
	echo "average is $ave"
		
else
	echo "Something wrong with the input parameters!"
	echo "how to call: ./3.sh with at least three numbers!"
	echo "example: ./3.sh 3 4 6 5"
fi

